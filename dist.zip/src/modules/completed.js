const boxChecked = (box) => {
  if (box.checked) {
    return true;
  }
  return false;
};
export default boxChecked;
