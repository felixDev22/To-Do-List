export const listItems = document.querySelector('.task-list');
export const addTask = document.querySelector('#new-task');
export const addBtn = document.getElementById('plus');
